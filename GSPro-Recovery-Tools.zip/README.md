# GSPro: публичные инструменты восстановления

Инструкция: https://github.com/nightengineer/GSPro-Instructions/blob/main/docs/recovery/Восстановление_из_S3.md

Сначала получите полный закрытый recovery-kit из собственного S3 и проверьте его MANIFEST.sha256. Для запуска installer нужны его backup-system/ и полный проверенный snapshot. Сохраните исходный kit; инструменты этого ZIP копируйте в отдельную рабочую копию по инструкции.

Изменения относительно S3: расшифровщик запрещает открытый ввод пароля вне TTY, installer разрешает только START_PUBLIC_SERVICES=false. Downloader и restore совпадают с S3. Полное развёртывание на чистом Ubuntu VPS этим пакетом не подтверждено.
